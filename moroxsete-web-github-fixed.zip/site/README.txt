MoroXsete Store — versión corregida para GitHub Pages

La bienvenida, la imagen de Hinata, el audio y las demás imágenes están incrustados dentro de `index.html`. Por eso esta versión puede funcionar aunque subas únicamente `index.html` al repositorio. La carpeta `assets` se incluye como respaldo, pero ya no es necesaria para que se vea la bienvenida.

La bienvenida aparece al entrar, muestra la imagen proporcionada, reproduce una voz de aproximadamente 12 segundos y se cierra automáticamente. Algunos navegadores de celular y computadora bloquean el sonido automático; si ocurre, pulsa el botón “Activar bienvenida con sonido”. La imagen sí debe aparecer automáticamente.

Para GitHub Pages, sube el archivo `index.html` a la raíz del repositorio `moroxsete-web`. También puedes subir la carpeta `assets` completa si deseas conservar los archivos originales. Después entra en Settings → Pages, selecciona Deploy from a branch, elige la rama `main` y la carpeta `/root`, y guarda.

Para probarla localmente, abre `index.html` o ejecuta `python3 -m http.server 8000` dentro de la carpeta `site` y visita `http://localhost:8000`.
